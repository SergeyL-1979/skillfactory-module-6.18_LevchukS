// $("#my-progress-bar").width();

const btnPrimary = $('.btn-primary'); 
const btnSecondary = $('.btn-secondary'); 
const btnThird = $('.btn-third'); 
let currentProgress = 0;

const width = 0;
// console.log('btnPrimary', btnPrimary); 
// console.log('btnSecondary', btnSecondary); 
// console.log('btnThird', btnThird); 
// console.log(label);
let elem = document.getElementById("myBar");
//     elem.style.width = currentProgress + '%';


btnPrimary.click(function() {
    // console.log('btnSecondary');
    // let width=$(".progress-bar").css("width");
    let width=$(".progress-bar").attr("width");
    // width=parseInt(width);
    // width+=(width*1);
    currentProgress = currentProgress + 1;
    // $(".progress-bar").css({"width":`${width}`});
    $(".progress-bar").attr("style", "width: " + currentProgress + "%");
    document.getElementById("label").innerHTML = width*1 +'%';
})

btnSecondary.click(function() {
    // console.log('btnSecondary');
    // let width=$(".progress-bar").css("width");
    // let width=$(".progress-bar").attr("width");
    // width=parseInt(width);
    // width+=(width*1);
    currentProgress = currentProgress + 3;
    // $(".progress-bar").css({"width":`${width}`});
    $(".progress-bar").attr("style", "width: " + currentProgress + "%");
})

btnThird.click(function() {
    // console.log('btnSecondary');
    // var width=$(".progress-bar").css("width");
    // let width=$(".progress-bar").attr("width");
    // width=parseInt(width);
    // width+=(width*1);
    currentProgress = currentProgress + 7;
    // $(".progress-bar").css({"width":`${width}`});
    $(".progress-bar").attr("style", "width: " + currentProgress + "%");
})

document.getElementById("label").innerHTML = width*1 +'%';
$('.progress-bar').width(currentProgress + "%");





// $('.progress-bar').width((Math.random() * 100) + '%')
// var btnPrimary = $('.btn-create');

// btnPrimary.click(function() {
//     // console.log('.width');
    
//     // $('.progress-bar').width((Math.random() * 100) + '%')
//     var width=$(".progress-bar").css("width");
//     width=parseInt(width);
//     width+=(width*100);
//     
//     $(".progress-bar").css({"width":`${width}`});
    
// })

// // рабочий код из примера
// let currentProgress = 0;
// function init() {
//        btnPrimary.click(function() {
//        currentProgress = currentProgress + 1;
//        console.log('currentProgress = ', currentProgress); 
//        $('.progress-bar').attr("style", "width: " + currentProgress + "%");
//    });
// }
// $(document).ready(init);




//  =============================================

// -----------------------------------------------
// ===============================================
// let currentProgress = 0;
// function init() {
//        btnSecondary.click(function() {
//        currentProgress = currentProgress + 3;
//        console.log('currentProgress = ', currentProgress); 
//        $('.progress-bar').attr("style", "width: " + currentProgress + "%");
//    });
// }


// btnThird.click(function() {
//     // console.log('btnThird');
//     var width=$(".progress-bar").css("width");
//     width=parseInt(width);
//     width+=(width*1.7);
//     $(".progress-bar").css({"width":`${width}`});    
// })
// =================================================

// var width=$(".progress-bar").css("width");
// width=parseInt(width);
// width+=(width*0.1);
// $(".progress-bar").css({"width":`${width}`});



